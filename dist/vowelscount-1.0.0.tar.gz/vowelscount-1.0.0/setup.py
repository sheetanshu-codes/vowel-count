from distutils.core import setup

setup(
    name="vowelscount",
    version="1.0.0",
    py_modules=["vowelscount"],
    author_email="shekhar.sheetanshu@gmail.com",
    url="http://standpointsports.com/",
    description="A function to count vowels in any text file"
    )
